// TJPzoom 3 configuration file * János Pál Tóth
// 2007.04.28
// Docs @ http://valid.tjp.hu/tjpzoom/ 
// News @ http://tjpzoom.blogspot.com/

// ROUNDFUN
// no HTML border,
// just a well prepared drop shadow called 'roundfun'. It has a rounded corner and some halo

var TJPzoomwidth=240;              //zoom window size
var TJPzoomheight=160; 
var TJPzoomwindowlock=0;           //set to 1 to lock window size

var TJPzoomamount=4;
var TJPzoomamountmax=12;
var TJPzoomamountmin=1;

var TJPborderthick=0;              //border thickness, SET 0 to no borders
var TJPbordercolor='#cccccc';      //border color

var TJPshadowthick=16;              //shadow image size/2, SET 0 to have no shadows (saves cpu)
var TJPshadow='roundfun/';       // <>: n, ne, e, se, s, sw, w, nw - TJPshadow+'nw.png'

// TJPzoom 3 configuration file * János Pál Tóth
// Docs @ http://valid.tjp.hu/tjpzoom/ 
// News @ http://tjpzoom.blogspot.com/
