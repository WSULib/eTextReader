// TJPzoom 3 configuration file * János Pál Tóth
// 2007.04.28
// Docs @ http://valid.tjp.hu/tjpzoom/ 
// News @ http://tjpzoom.blogspot.com/

// PURITYU
// no HTML border
// no drop shadow
// fixed zoom amount (TJPzoomamount==TJPzoomamountmax==TJPzoomamountmin)
// locked zoom window (no dragging left/right)

var TJPzoomwidth=320;              //zoom window size
var TJPzoomheight=200; 
var TJPzoomwindowlock=1;           //set to 1 to lock window size

var TJPzoomoffset='';   //turning off smart mode
var TJPzoomoffsetx=1/2; //where is the zoom box relative to the mouse cursor - choose a number between 0 and 1 and see what happens ;]
var TJPzoomoffsety=1/2;

var TJPzoomamount=4;
var TJPzoomamountmax=4;
var TJPzoomamountmin=4;

var TJPborderthick=0;              //border thickness, SET 0 to no borders
var TJPbordercolor='#ff0000';      //border color

var TJPshadowthick=0;              //shadow image size/2, SET 0 to have no shadows (saves cpu)
var TJPshadow='';                  // <>: n, ne, e, se, s, sw, w, nw - TJPshadow+'nw.png'

// TJPzoom 3 configuration file * János Pál Tóth
// Docs @ http://valid.tjp.hu/tjpzoom/ 
// News @ http://tjpzoom.blogspot.com/
