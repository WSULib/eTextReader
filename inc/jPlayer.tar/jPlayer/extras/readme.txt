
jquery.jplayer.combo.min.js
---------------------------
Contains:
  jQuery 1.8.2 excluded modules: -ajax, -deprecated
  jPlayer 2.2.0

This file contains both jQuery (min build) and jPlayer.
It is intended for use where you only use jPlayer on your site.
ie., You do not use jQuery for other functionality, such as AJAX requests.


jquery.jplayer.playlist.combo.min.js
---------------------------
Contains:
  jQuery 1.8.2 excluded modules: -ajax, -deprecated
  jPlayer 2.2.0
  jPlayerPlaylist 2.1.0

This file contains both jQuery (min build), jPlayer and jPlayerPlaylist.
It is intended for use where you only use jPlayerPlaylist on your site.
ie., You do not use jQuery for other functionality, such as AJAX requests.


jquery-1.8.2-ajax-deprecated.min.js
-----------------------------------
Contains:
  jQuery 1.8.2 excluded modules: -ajax, -deprecated

This is the minimum build of jQuery, that works with jPlayer.
ie., The AJAX features and deprecated commands have been removed.
